# Import Libraries
from psychopy import visual, core, event
from psychopy import gui
import pandas as pd
import glob
import random
from triggers import setParallelData
import os

#Defining GUI
introgui=gui.Dlg(title = "Is this a face?")
introgui.addField("Participant ID:")
introgui.addField("Age:")
introgui.addField("Gender:", choices=["Female","Male","other"])
introgui.show()
if introgui.OK:
    ID=introgui.data[0]
    Age=introgui.data[1]
    Gender=introgui.data[2]
    [ID,Age,Gender]=introgui.data
elif introgui.Cancel:
    core.quit()

#Make triggers
from psychopy import data
#defining cols
cols=["ID","Age","Gender","Stimulus", "ReactionTime", "Face","Key"]
#creating df
logfile=pd.DataFrame(columns=cols)
#Get data
date=data.getDateStr()
 #Create a Window
win=visual.Window(color="black", fullscr=True)

# Load Images
path=os.path.join('stimuli')
stimuli = os.listdir(path)
stimuli = [os.path.join('stimuli', f) for f in stimuli if f.endswith(".jpg")]
random.shuffle(stimuli)

#Intro
msg=visual.TextStim(win, text = "Welcome, press any key to continue, have a blast! Your task for today will be to decide as soon as possible whether the presented stimulus remind you of a face or not. You will be able to answer via left arrow for no and right arrow for yes")
msg.draw()
win.flip()
event.waitKeys()
# Loop Through Trials
for stimulus in stimuli:
    msg_2=visual.TextStim(win, text = "< = No,      Yes = >", pos = (0, -0.8))
    picSize = 1
    pic=visual.ImageStim(win,stimulus)
    pic.size *= picSize / max(pic.size)
    
    #define triggers
    if 'object' in stimulus:
        trigger = 11
    elif 'Face'in stimulus:
        trigger = 21
    elif 'pareidolia' in stimulus:
        trigger = 31
    
    # Draw the Stimuli
    pic.draw()
    msg_2.draw()
    win.callOnFlip(setParallelData, trigger)  
    pullTriggerDown = True
    win.flip()
    if pullTriggerDown: 
        win.callOnFlip(setParallelData, 0)
        pullTriggerDown = False
    #define clock watch
    stopwatch=core.Clock()
    # Reset and Start the Clock
    stopwatch.reset()
    #key recording
    key=event.waitKeys(keyList = ["left","right","escape"])
    #RT
    reaction_time = stopwatch.getTime()
    
    #resp_key=event.getKeys(keyList = ("left","right"), timeStamped=False) not necessary
    print(key)
    #if resp_key==["left"] or ["right"]:
     #   event.getKeys()
    #escape
    print(reaction_time)
    if key[0] == "escape":
        core.quit()
    if key==["left"] and stimulus[-7]=="F":
        stopwatch = core.Clock()
    win.flip()
    core.wait(0.8)
    
    #data saving
    logfile=logfile.append({
        "Data": date,
        "ID": ID, 
        "Age": Age,
        "Gender": Gender,
        "Stimulus": stimulus,
        "Trigger": trigger,
        "ReactionTime" : reaction_time,
        "Key" : key
        },ignore_index=True)


#logfile name
logfile_name="logfiles/logfile_{}_{}.csv".format(ID,date)

#Saving the log file
logfile.to_csv(logfile_name)